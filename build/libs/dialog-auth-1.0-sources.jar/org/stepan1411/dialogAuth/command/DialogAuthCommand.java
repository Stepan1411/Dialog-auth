package org.stepan1411.dialogAuth.command;

import com.mojang.brigadier.CommandDispatcher;
import com.mojang.brigadier.arguments.StringArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_3222;
import net.minecraft.class_7924;
import org.stepan1411.dialogAuth.DialogAuth;
import org.stepan1411.dialogAuth.config.ConfigManager;
import org.stepan1411.dialogAuth.storage.PasswordStorage;

public class DialogAuthCommand {
    
    public static void register(CommandDispatcher<class_2168> dispatcher) {
        dispatcher.register(
            class_2170.method_9247("dialogauth")
                .then(class_2170.method_9247("register")
                    .executes(DialogAuthCommand::executeRegisterNoArgs) // Без аргументов - открыть диалог
                    .then(class_2170.method_9244("passwords", StringArgumentType.greedyString())
                        .executes(DialogAuthCommand::executeRegisterGreedy)
                    )
                )
                .then(class_2170.method_9247("login")
                    .executes(DialogAuthCommand::executeLoginNoArgs) // Без аргументов - открыть диалог
                    .then(class_2170.method_9244("password", StringArgumentType.greedyString())
                        .executes(DialogAuthCommand::executeLogin)
                    )
                )
                .then(class_2170.method_9247("leave")
                    .executes(DialogAuthCommand::executeLeave)
                )
                .then(class_2170.method_9247("changepass")
                    .executes(DialogAuthCommand::executeChangePass)
                )
                .then(class_2170.method_9247("changepassdialog")
                    .executes(DialogAuthCommand::executeChangePassDialogNoArgs) // Без аргументов - открыть диалог
                    .then(class_2170.method_9244("passwords", StringArgumentType.greedyString())
                        .executes(DialogAuthCommand::executeChangePassDialog)
                    )
                )
                .then(class_2170.method_9247("leavechangepass")
                    .executes(DialogAuthCommand::executeLeaveChangePass)
                )
                .then(class_2170.method_9247("reload")
                    .executes(DialogAuthCommand::executeReload)
                )
        );
    }
    
    private static int executeRegisterGreedy(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by players"));
            return 0;
        }
        
        // Проверяем, что игрок в auth измерении
        if (!DialogAuth.isPlayerInAuthDimension(player, source.method_9211())) {
            source.method_9213(class_2561.method_43470("§cThis command can only be used during authentication!"));
            return 0;
        }
        
        String passwords = StringArgumentType.getString(context, "passwords");
        String[] parts = passwords.split(" ", 2);
        
        // Если меньше 2 частей, значит не хватает аргументов
        if (parts.length < 2) {
            // Открываем диалог снова
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "register");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            }
            return 0;
        }
        
        String password1 = parts[0].trim();
        String password2 = parts[1].trim();
        
        return processRegistration(source, player, password1, password2);
    }
    
    private static int executeRegisterNoArgs(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by players"));
            return 0;
        }
        
        // Проверяем, что игрок в auth измерении
        if (!DialogAuth.isPlayerInAuthDimension(player, source.method_9211())) {
            source.method_9213(class_2561.method_43470("§cThis command can only be used during authentication!"));
            return 0;
        }
        
        // Открываем диалог регистрации снова
        class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "register");
        var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
        var dialogEntry = dialogRegistry.method_10223(dialogId);
        
        if (dialogEntry.isPresent()) {
            player.method_71753(dialogEntry.get());
        } else {
            source.method_9213(class_2561.method_43470("Registration dialog not found!"));
        }
        
        return 1;
    }
    
    private static int executeLoginNoArgs(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by players"));
            return 0;
        }
        
        // Проверяем, что игрок в auth измерении
        if (!DialogAuth.isPlayerInAuthDimension(player, source.method_9211())) {
            source.method_9213(class_2561.method_43470("§cThis command can only be used during authentication!"));
            return 0;
        }
        
        // Открываем диалог логина снова
        class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "login");
        var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
        var dialogEntry = dialogRegistry.method_10223(dialogId);
        
        if (dialogEntry.isPresent()) {
            player.method_71753(dialogEntry.get());
        } else {
            source.method_9213(class_2561.method_43470("Login dialog not found!"));
        }
        
        return 1;
    }
    
    private static int executeLogin(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by players"));
            return 0;
        }
        
        // Проверяем, что игрок в auth измерении
        if (!DialogAuth.isPlayerInAuthDimension(player, source.method_9211())) {
            source.method_9213(class_2561.method_43470("§cThis command can only be used during authentication!"));
            return 0;
        }
        
        String password = StringArgumentType.getString(context, "password");
        
        // Убираем _ в конце если он есть (placeholder из диалога)
        if (password.endsWith("_")) {
            password = password.substring(0, password.length() - 1);
        }
        
        password = password.trim();
        
        // Если пароль пустой после trim, показываем диалог с ошибкой
        if (password.isEmpty()) {
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "login_empty");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            }
            return 0;
        }
        
        // Проверяем длину пароля
        int minLength = ConfigManager.getMinPasswordLength();
        if (password.length() < minLength) {
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "login_short");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            }
            return 0;
        }
        
        // Проверяем пароль
        String username = player.method_5477().getString();
        if (!PasswordStorage.checkPassword(username, password)) {
            // Неправильный пароль
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "login_error");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            }
            return 0;
        }
        
        // Успешный логин
        DialogAuth.LOGGER.info("Player {} logged in successfully", username);
        source.method_9226(() -> class_2561.method_43470("§aSuccessfully logged in!"), false);
        
        // Возвращаем игрока в мир
        boolean success = DialogAuth.returnPlayerToWorld(player, source.method_9211());
        
        if (!success) {
            source.method_9213(class_2561.method_43470("Failed to return to world"));
            return 0;
        }
        
        return 1;
    }
    
    private static int processRegistration(class_2168 source, class_3222 player, String password1, String password2) {
        // Проверяем, что пароли не пустые
        if (password1.isEmpty() || password2.isEmpty()) {
            // Открываем диалог с ошибкой о пустом пароле
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "register_empty");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            } else {
                source.method_9213(class_2561.method_43470("Password cannot be empty!"));
            }
            return 0;
        }
        
        // Проверяем, что пароли совпадают
        if (!password1.equals(password2)) {
            // Открываем диалог с ошибкой
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "register_error");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            } else {
                source.method_9213(class_2561.method_43470("Passwords do not match!"));
            }
            return 0;
        }
        
        // Проверяем длину пароля
        int minLength = ConfigManager.getMinPasswordLength();
        if (password1.length() < minLength) {
            // Открываем диалог с ошибкой о коротком пароле
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "register_short");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            } else {
                source.method_9213(class_2561.method_43470("Password must be at least " + minLength + " characters long!"));
            }
            return 0;
        }
        
        // Логируем регистрацию
        DialogAuth.LOGGER.info(ConfigManager.getMessage("logging.player_registered", "player", player.method_5477().getString(), "password", password1));
        
        // Сохраняем пароль
        PasswordStorage.registerPlayer(player.method_5477().getString(), player.method_5667(), password1);
        
        // Отправляем сообщение игроку
        final String finalPassword = password1;
        String successMsg = ConfigManager.getMessage("command.register.success", "password", finalPassword);
        source.method_9226(() -> class_2561.method_43470(successMsg), false);
        
        // Возвращаем игрока в мир
        boolean success = DialogAuth.returnPlayerToWorld(player, source.method_9211());
        
        if (!success) {
            source.method_9213(class_2561.method_43470("Failed to return to world"));
            return 0;
        }
        
        return 1;
    }
    
    private static int executeRegister(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by players"));
            return 0;
        }
        
        String password1 = StringArgumentType.getString(context, "password1");
        String password2 = StringArgumentType.getString(context, "password2");
        
        // Заменяем _ на пустую строку (значение по умолчанию из диалога)
        if (password1.equals("_")) password1 = "";
        if (password2.equals("_")) password2 = "";
        
        // Проверяем, что пароли не пустые
        if (password1.isEmpty() || password2.isEmpty()) {
            // Открываем диалог с ошибкой о пустом пароле
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "register_empty");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            } else {
                source.method_9213(class_2561.method_43470("Password cannot be empty!"));
            }
            return 0;
        }
        
        // Проверяем, что пароли совпадают
        if (!password1.equals(password2)) {
            // Открываем диалог с ошибкой
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "register_error");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            } else {
                source.method_9213(class_2561.method_43470("Passwords do not match!"));
            }
            return 0;
        }
        
        // Проверяем длину пароля
        if (password1.length() < 4) {
            // Открываем диалог с ошибкой о коротком пароле
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "register_short");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            } else {
                source.method_9213(class_2561.method_43470("Password must be at least 4 characters long!"));
            }
            return 0;
        }
        
        // Финальная переменная для использования в лямбде
        final String finalPassword = password1;
        
        // Логируем регистрацию
        DialogAuth.LOGGER.info("Player {} registered with password: {}", player.method_5477().getString(), finalPassword);
        
        // Отправляем сообщение игроку
        source.method_9226(() -> class_2561.method_43470("§aSuccessfully registered with password: §e" + finalPassword), false);
        
        // Возвращаем игрока в мир
        boolean success = DialogAuth.returnPlayerToWorld(player, source.method_9211());
        
        if (!success) {
            source.method_9213(class_2561.method_43470("Failed to return to world"));
            return 0;
        }
        
        return 1;
    }
    
    private static int executeLeave(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470(ConfigManager.getMessage("command.leave.player_only")));
            return 0;
        }
        
        // Проверяем, что игрок в auth измерении
        if (!DialogAuth.isPlayerInAuthDimension(player, source.method_9211())) {
            source.method_9213(class_2561.method_43470(ConfigManager.getMessage("command.leave.only_in_auth")));
            return 0;
        }
        
        // Сначала возвращаем игрока в мир
        boolean success = DialogAuth.returnPlayerToWorld(player, source.method_9211());
        
        String disconnectMsg = ConfigManager.getMessage("command.leave.disconnect_message");
        
        if (success) {
            // Ждём немного, чтобы телепортация завершилась, затем кикаем
            source.method_9211().execute(() -> {
                try {
                    Thread.sleep(50); // Небольшая задержка
                } catch (InterruptedException e) {
                    // Игнорируем
                }
                player.field_13987.method_52396(class_2561.method_43470(disconnectMsg));
            });
        } else {
            // Если не удалось вернуть, просто кикаем
            player.field_13987.method_52396(class_2561.method_43470(disconnectMsg));
        }
        
        return 1;
    }
    
    private static int executeReload(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        ConfigManager.ReloadResult result = ConfigManager.reload();
        
        if (result.hasError()) {
            String errorMsg = ConfigManager.getMessage("command.reload.failed", "error", result.error);
            source.method_9213(class_2561.method_43470(errorMsg));
            return 0;
        }
        
        if (!result.hasChanges()) {
            source.method_9226(() -> class_2561.method_43470("§eNo changes detected in configuration files"), false);
            return 1;
        }
        
        String successMsg = ConfigManager.getMessage("command.reload.success");
        
        if (result.dialogsChanged) {
            String noteMsg = ConfigManager.getMessage("command.reload.note");
            source.method_9226(() -> class_2561.method_43470(successMsg + "\n" + noteMsg), true);
        } else {
            source.method_9226(() -> class_2561.method_43470(successMsg), true);
        }
        
        return 1;
    }
    
    private static int executeChangePass(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by players"));
            return 0;
        }
        
        // Телепортируем игрока в auth измерение
        DialogAuth.teleportToAuthForChangePass(player, source.method_9211());
        
        return 1;
    }
    
    private static int executeChangePassDialogNoArgs(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by players"));
            return 0;
        }
        
        // Проверяем, что игрок в auth измерении
        if (!DialogAuth.isPlayerInAuthDimension(player, source.method_9211())) {
            source.method_9213(class_2561.method_43470("§cThis command can only be used during authentication!"));
            return 0;
        }
        
        // Открываем диалог changepass снова
        class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "changepass");
        var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
        var dialogEntry = dialogRegistry.method_10223(dialogId);
        
        if (dialogEntry.isPresent()) {
            player.method_71753(dialogEntry.get());
        }
        
        return 1;
    }
    
    private static int executeChangePassDialog(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by players"));
            return 0;
        }
        
        // Проверяем, что игрок в auth измерении
        if (!DialogAuth.isPlayerInAuthDimension(player, source.method_9211())) {
            source.method_9213(class_2561.method_43470("§cThis command can only be used during authentication!"));
            return 0;
        }
        
        String passwords = StringArgumentType.getString(context, "passwords");
        String[] parts = passwords.split(" ", 2);
        
        // Если меньше 2 частей, значит не хватает аргументов
        if (parts.length < 2) {
            // Открываем диалог снова
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "changepass");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            }
            return 0;
        }
        
        String oldPassword = parts[0].trim();
        String newPassword = parts[1].trim();
        
        // Проверяем, что пароли не пустые
        if (oldPassword.isEmpty() || newPassword.isEmpty()) {
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "changepass_empty");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            }
            return 0;
        }
        
        // Проверяем, что новый пароль отличается от старого
        if (oldPassword.equals(newPassword)) {
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "changepass_same");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            }
            return 0;
        }
        
        // Проверяем длину нового пароля
        int minLength = ConfigManager.getMinPasswordLength();
        if (newPassword.length() < minLength) {
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "changepass_short");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            }
            return 0;
        }
        
        // Проверяем старый пароль
        String username = player.method_5477().getString();
        if (!PasswordStorage.checkPassword(username, oldPassword)) {
            // Неправильный старый пароль
            class_2960 dialogId = class_2960.method_60655(DialogAuth.MOD_ID, "changepass_error_oldpass");
            var dialogRegistry = source.method_9211().method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            }
            return 0;
        }
        
        // Меняем пароль
        PasswordStorage.changePassword(username, newPassword);
        source.method_9226(() -> class_2561.method_43470("§aPassword changed successfully!"), false);
        
        // Возвращаем игрока в мир
        boolean success = DialogAuth.returnPlayerToWorld(player, source.method_9211());
        
        if (!success) {
            source.method_9213(class_2561.method_43470("Failed to return to world"));
            return 0;
        }
        
        return 1;
    }
    
    private static int executeLeaveChangePass(CommandContext<class_2168> context) {
        class_2168 source = context.getSource();
        
        if (!(source.method_9228() instanceof class_3222 player)) {
            source.method_9213(class_2561.method_43470("This command can only be used by players"));
            return 0;
        }
        
        // Проверяем, что игрок в auth измерении
        if (!DialogAuth.isPlayerInAuthDimension(player, source.method_9211())) {
            source.method_9213(class_2561.method_43470("§cThis command can only be used during authentication!"));
            return 0;
        }
        
        // Возвращаем игрока в мир без кика
        DialogAuth.returnPlayerToWorld(player, source.method_9211());
        
        return 1;
    }
}

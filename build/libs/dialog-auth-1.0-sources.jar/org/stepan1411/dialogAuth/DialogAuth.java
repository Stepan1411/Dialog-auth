package org.stepan1411.dialogAuth;

import com.mojang.brigadier.CommandDispatcher;
import net.fabricmc.api.ModInitializer;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.minecraft.class_1934;
import net.minecraft.class_1937;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5321;
import net.minecraft.class_5454;
import net.minecraft.class_7924;
import net.minecraft.server.MinecraftServer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.stepan1411.dialogAuth.command.DialogAuthCommand;
import org.stepan1411.dialogAuth.config.ConfigManager;
import org.stepan1411.dialogAuth.storage.PasswordStorage;

import java.util.HashMap;
import java.util.Map;
import java.util.UUID;

public class DialogAuth implements ModInitializer {

    public static final String MOD_ID = "dialog_auth";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);
    
    // Хранилище для сохранения позиций игроков
    private static final Map<UUID, PlayerLocation> savedLocations = new HashMap<>();
    
    // Игроки в процессе аутентификации
    private static final Map<UUID, Boolean> authenticatingPlayers = new HashMap<>();
    
    // Ключ измерения auth
    public static final class_5321<class_1937> AUTH_DIMENSION = class_5321.method_29179(
        class_7924.field_41223,
        class_2960.method_60655(MOD_ID, "auth")
    );

    @Override
    public void onInitialize() {
        LOGGER.info("DialogAuth mod initialized!");
        
        // Создаем конфигурационные файлы
        ConfigManager.initialize();
        
        // Инициализируем хранилище паролей
        PasswordStorage.initialize();
        
        // Регистрируем команды
        CommandRegistrationCallback.EVENT.register((dispatcher, registryAccess, environment) -> {
            DialogAuthCommand.register(dispatcher);
        });
        
        // Проверяем игроков каждый тик
        ServerTickEvents.END_SERVER_TICK.register(this::onServerTick);
        
        // Отменяем спавн мобов в измерении auth
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerEntityEvents.ENTITY_LOAD.register((entity, world) -> {
            // Если это моб в измерении auth - удаляем его
            if (world.method_27983().equals(AUTH_DIMENSION) && entity instanceof net.minecraft.class_1308) {
                entity.method_31472();
                LOGGER.debug("Prevented mob spawn in auth dimension: {}", entity.method_5864().method_5897().getString());
            }
        });
        
        // Показываем диалог при входе игрока на сервер
        ServerPlayConnectionEvents.JOIN.register((handler, sender, server) -> {
            class_3222 player = handler.method_32311();
            
            server.execute(() -> {
                // Получаем IP адрес игрока
                String ipAddress = getPlayerIpAddress(player);
                
                // Проверяем, зарегистрирован ли игрок
                boolean isRegistered = PasswordStorage.isPlayerRegistered(player.method_5477().getString());
                
                // Проверяем, нужна ли аутентификация
                boolean needsAuth = !isRegistered || PasswordStorage.needsLogin(player.method_5477().getString(), ipAddress);
                
                if (needsAuth) {
                    // Нужна аутентификация - сохраняем позицию и телепортируем в auth
                    
                    // Сохраняем позицию только если её ещё нет
                    if (!savedLocations.containsKey(player.method_5667())) {
                        // Игрок всегда заходит в оверворлд при первом подключении
                        class_3218 world = server.method_30002();
                        class_243 pos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());
                        float yaw = player.method_36454();
                        float pitch = player.method_36455();
                        class_1934 gameMode = player.field_13974.method_14257();
                        
                        PlayerLocation location = new PlayerLocation(
                            world.method_27983(),
                            pos,
                            yaw,
                            pitch,
                            gameMode
                        );
                        savedLocations.put(player.method_5667(), location);
                    }
                    
                    // Помечаем игрока как аутентифицирующегося
                    authenticatingPlayers.put(player.method_5667(), true);
                    
                    // Телепортируем в измерение auth
                    teleportToAuth(player, server);
                    
                    // Показываем диалог
                    showAuthDialog(player, server, isRegistered);
                } else {
                    // Сессия активна - пропускаем аутентификацию
                    LOGGER.info("Player {} has valid session, skipping authentication", player.method_5477().getString());
                }
            });
        });
        
        // Убираем игрока из списков при выходе
        ServerPlayConnectionEvents.DISCONNECT.register((handler, server) -> {
            UUID uuid = handler.method_32311().method_5667();
            authenticatingPlayers.remove(uuid);
            savedLocations.remove(uuid);
        });
    }
    
    private void onServerTick(MinecraftServer server) {
        // Можно добавить дополнительную логику здесь при необходимости
    }
    
    private void teleportToAuth(class_3222 player, MinecraftServer server) {
        class_3218 authWorld = server.method_3847(AUTH_DIMENSION);
        
        if (authWorld == null) {
            LOGGER.error("Auth dimension not found!");
            return;
        }
        
        // Устанавливаем режим наблюдателя
        player.method_7336(class_1934.field_9219);
        
        // Телепортируем в центр измерения auth
        class_243 targetPos = new class_243(0.5, 65, 0.5);
        class_5454 target = new class_5454(authWorld, targetPos, class_243.field_1353, 0, 0, class_5454.field_52245);
        
        player.method_61275(target);
    }
    
    private void showAuthDialog(class_3222 player, MinecraftServer server, boolean isRegistered) {
        if (!isRegistered) {
            // Не зарегистрирован - показываем регистрацию
            class_2960 dialogId = class_2960.method_60655(MOD_ID, "register");
            var dialogRegistry = server.method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            } else {
                LOGGER.error("Dialog {} not found in registry!", dialogId);
            }
        } else {
            // Зарегистрирован - показываем логин
            class_2960 dialogId = class_2960.method_60655(MOD_ID, "login");
            var dialogRegistry = server.method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            } else {
                LOGGER.error("Dialog {} not found in registry!", dialogId);
            }
        }
    }
    
    public static boolean returnPlayerToWorld(class_3222 player, MinecraftServer server) {
        PlayerLocation location = savedLocations.remove(player.method_5667());
        
        if (location == null) {
            return false;
        }
        
        class_3218 targetWorld = server.method_3847(location.dimension);
        
        if (targetWorld == null) {
            return false;
        }
        
        // Телепортируем обратно
        class_5454 target = new class_5454(
            targetWorld,
            location.position,
            class_243.field_1353,
            location.yaw,
            location.pitch,
            class_5454.field_52245
        );
        
        player.method_61275(target);
        
        // Восстанавливаем режим игры
        player.method_7336(location.gameMode);
        
        // Убираем из списка аутентифицирующихся
        authenticatingPlayers.remove(player.method_5667());
        
        return true;
    }
    
    public static boolean isPlayerInAuthDimension(class_3222 player, MinecraftServer server) {
        // Получаем auth мир
        class_3218 authWorld = server.method_3847(AUTH_DIMENSION);
        if (authWorld == null) return false;
        
        // Сравниваем через поле world (которое protected в Entity)
        // Используем рефлексию или альтернативный способ
        try {
            var worldField = net.minecraft.class_1297.class.getDeclaredField("world");
            worldField.setAccessible(true);
            Object playerWorld = worldField.get(player);
            return playerWorld == authWorld;
        } catch (Exception e) {
            return false;
        }
    }
    
    public static String getPlayerIpAddress(class_3222 player) {
        try {
            var connectionField = net.minecraft.class_8609.class.getDeclaredField("connection");
            connectionField.setAccessible(true);
            Object connection = connectionField.get(player.field_13987);
            if (connection instanceof net.minecraft.class_2535) {
                String fullAddress = ((net.minecraft.class_2535) connection).method_10755().toString();
                // Убираем порт из адреса (например "/127.0.0.1:12345" -> "127.0.0.1")
                if (fullAddress.startsWith("/")) {
                    fullAddress = fullAddress.substring(1);
                }
                int colonIndex = fullAddress.indexOf(':');
                if (colonIndex > 0) {
                    return fullAddress.substring(0, colonIndex);
                }
                return fullAddress;
            }
        } catch (Exception e) {
            LOGGER.error("Failed to get player IP address", e);
        }
        return "unknown";
    }
    
    public static void teleportToAuthForChangePass(class_3222 player, MinecraftServer server) {
        // Проверяем, что игрок НЕ в auth измерении
        if (isPlayerInAuthDimension(player, server)) {
            LOGGER.warn("Player {} is already in auth dimension, not saving location", player.method_5477().getString());
            // Просто показываем диалог без сохранения позиции
            class_2960 dialogId = class_2960.method_60655(MOD_ID, "changepass");
            var dialogRegistry = server.method_30611().method_30530(class_7924.field_60818);
            var dialogEntry = dialogRegistry.method_10223(dialogId);
            
            if (dialogEntry.isPresent()) {
                player.method_71753(dialogEntry.get());
            } else {
                LOGGER.error("Dialog {} not found in registry!", dialogId);
            }
            return;
        }
        
        // Получаем текущий мир игрока через рефлексию
        class_3218 currentWorld = null;
        try {
            var worldField = net.minecraft.class_1297.class.getDeclaredField("world");
            worldField.setAccessible(true);
            Object playerWorld = worldField.get(player);
            if (playerWorld instanceof class_3218) {
                currentWorld = (class_3218) playerWorld;
            }
        } catch (Exception e) {
            LOGGER.error("Failed to get player world", e);
            currentWorld = server.method_30002(); // Fallback to overworld
        }
        
        // Сохраняем текущую позицию игрока
        class_243 pos = new class_243(player.method_23317(), player.method_23318(), player.method_23321());
        float yaw = player.method_36454();
        float pitch = player.method_36455();
        class_1934 gameMode = player.field_13974.method_14257();
        
        PlayerLocation location = new PlayerLocation(
            currentWorld.method_27983(),
            pos,
            yaw,
            pitch,
            gameMode
        );
        savedLocations.put(player.method_5667(), location);
        
        // Телепортируем в auth измерение
        class_3218 authWorld = server.method_3847(AUTH_DIMENSION);
        
        if (authWorld == null) {
            LOGGER.error("Auth dimension not found!");
            return;
        }
        
        // Устанавливаем режим наблюдателя
        player.method_7336(class_1934.field_9219);
        
        // Телепортируем в центр измерения auth
        class_243 targetPos = new class_243(0.5, 65, 0.5);
        class_5454 target = new class_5454(authWorld, targetPos, class_243.field_1353, 0, 0, class_5454.field_52245);
        
        player.method_61275(target);
        
        // Показываем диалог смены пароля
        class_2960 dialogId = class_2960.method_60655(MOD_ID, "changepass");
        var dialogRegistry = server.method_30611().method_30530(class_7924.field_60818);
        var dialogEntry = dialogRegistry.method_10223(dialogId);
        
        if (dialogEntry.isPresent()) {
            player.method_71753(dialogEntry.get());
        } else {
            LOGGER.error("Dialog {} not found in registry!", dialogId);
        }
    }
    
    private record PlayerLocation(
        class_5321<class_1937> dimension,
        class_243 position,
        float yaw,
        float pitch,
        class_1934 gameMode
    ) {}
}
